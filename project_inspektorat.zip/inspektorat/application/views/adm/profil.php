<?php
//--> include data header
$this->load->view('layout/header');
//--> include data top navigasi
$this->load->view('layout/top_nav');
//--> include data sidebar navigasi
$this->load->view('layout/nav_sidebar');
?>

			<div class="main-content">
				<div class="main-content-inner">

					<div class="breadcrumbs ace-save-state" id="breadcrumbs">
						<ul class="breadcrumb">
							<li>
								<i class="ace-icon fa fa-home home-icon"></i> Home
						</ul><!-- /.breadcrumb -->
					</div>

					<div class="page-content">

						<div class="page-header">
							<h1>
								Profil
								<small>
									<i class="ace-icon fa fa-angle-double-right"></i>
									ADMINISTRATOR
								</small>
							</h1>
						</div><!-- /.page-header -->

						<div class="row">
							<div class="col-xs-12">
								<!-- PAGE CONTENT BEGINS -->

								<div class="row">
									<div class="col-sm-12">


										<div class="tabbable">
											<ul class="nav nav-tabs" id="myTab">
												<li class="active">
													<a data-toggle="tab" href="#password">
														<i class="red ace-icon fa fa-key bigger-120"></i>
														Username & Password
													</a>
												</li>
											</ul>


											<form class="form-horizontal" role="form" action="<?=site_url('adm/home/setting_ubah/'. base64_encode($pegawai->id_fk)); ?>" method="post">
											<div class="tab-content">

												<div id="password" class="tab-pane fade in active">
													<div class="row">

														<br/>

														<div class="col-sm-6">
															<div class="form-group">
																<label class="col-sm-3 control-label no-padding-right"> Username </label>
																<div class="col-sm-9">
																	<input type="text" name="username" class="col-sm-5" value="<?=$pegawai->username; ?>" />
																</div>
															</div>

															<div class="form-group">
																<label class="col-sm-3 control-label no-padding-right"> Password </label>
																<div class="col-sm-9">
																	<input type="text" name="password" class="col-sm-5" value="<?= base64_decode($pegawai->password); ?>" />
																</div>
															</div>

															<div class="clearfix form-actions">
																<div align="center">
																	<a href="javascript:history.back()" class="btn">
																		<i class="ace-icon fa fa-arrow-left"></i>
																		Kembali
																	</a>

																	&nbsp; &nbsp;

																	<input class="btn btn-info" type="submit" name="submit" value="Ubah"></input>
																</div>
															</div>
														</div>

													</div>
												</div><!-- /.password -->

											</div>
											</form>
										</div>

									</div>
								</div>

								<!-- PAGE CONTENT ENDS -->
							</div><!-- /.col -->
						</div><!-- /.row -->

					</div><!-- /.page-content -->
				</div>
			</div><!-- /.main-content -->

<!-- include data footer -->
<?php $this->load->view('layout/footer'); ?>

	</body>
</html>
