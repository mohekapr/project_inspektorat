<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggaran_waktu extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
		$this->auth->cek_auth(); //--> ambil auth dari library

		//--> load model
		$this->load->model('notifikasi_m');
		$this->load->model('ketua_tim/anggaran_waktu_m');
		$this->load->model('staff/penugasan_m');
		$this->load->model('staff/tim_m');
		$this->load->model('staff/pegawai_m');

		$this->load->model('staff/surat_m');

		//--> hak akses
		$hak_akses = $this->session->userdata('lvl');
		if($hak_akses!='ketua_tim')
		{
			echo "<script>alert('Anda tidak berhak mengakses halaman ini!!');</script>";
			redirect('log_in','refresh');
			exit();
		}
		// ./hak akses
	}

	//--> list anggaran waktu
	public function index()
	{
		$get_akun  = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'anggaran'     => $this->anggaran_waktu_m->get_anggaran_waktu($kt->id_pegawai)
			);

		$this->load->view('ketua_tim/anggaran_waktu/list_anggaran_waktu', $data);
	}

	//--> detail anggaran waktu
	public function detail_anggaran_waktu($id_agr)
	{
		$get_akun = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$key = base64_decode($id_agr);

		//-> update notif penugasan
		$this->notifikasi_m->update_notif_ketua($key);

		$data_agr = $this->anggaran_waktu_m->get_row_anggaran_waktu($key);

		//--> tgl persiapan, pelaksanaan, dan penyelesaian
		$tgl1_persiapan = date('d', strtotime($data_agr->tgl1_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_persiapan))) ." ".
							 date('Y', strtotime($data_agr->tgl1_persiapan));
		$tgl2_persiapan = date('d', strtotime($data_agr->tgl2_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_persiapan))) ." ".
							 date('Y', strtotime($data_agr->tgl2_persiapan));

		$tgl1_pelaksanaan = date('d', strtotime($data_agr->tgl1_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->tgl1_pelaksanaan));
		$tgl2_pelaksanaan = date('d', strtotime($data_agr->tgl2_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->tgl2_pelaksanaan));

		$tgl1_penyelesaian = date('d', strtotime($data_agr->tgl1_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->tgl1_penyelesaian));
		$tgl2_penyelesaian = date('d', strtotime($data_agr->tgl2_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->tgl2_penyelesaian));

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'data'         => $data_agr,
				'anggaran'     => $this->anggaran_waktu_m->get_sub_anggaran_waktu($key),
				'tgl1_1'       => $tgl1_persiapan,
				'tgl2_1'       => $tgl2_persiapan,
				'tgl1_2'       => $tgl1_pelaksanaan,
				'tgl2_2'       => $tgl2_pelaksanaan,
				'tgl1_3'       => $tgl1_penyelesaian,
				'tgl2_3'       => $tgl2_penyelesaian,
				'cek_rev'      => $this->anggaran_waktu_m->cek_reviu($key),
				'data_rev'     => $this->anggaran_waktu_m->get_rev_anggaran_waktu($key)
			);

		$this->load->view('ketua_tim/anggaran_waktu/detail_anggaran_waktu', $data);
	}

	//--> detail reviu
	public function detail_reviu($id_agr, $no_rev)
	{
		$get_akun = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$key  = base64_decode($id_agr);
		$key2 = base64_decode($no_rev);

		$data_agr = $this->anggaran_waktu_m->get_row_rev_anggaran_waktu($key, $key2);

		$tgl_rev  = date('d', strtotime($data_agr->tgl_reviu)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_reviu))) ." ".
							 date('Y', strtotime($data_agr->tgl_reviu)) ." | ".
							 date('H:i:s', strtotime($data_agr->tgl_reviu));

		$tgl_rev_dn  = date('d', strtotime($data_agr->tgl_rev_dalnis)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_rev_dalnis))) ." ".
							 date('Y', strtotime($data_agr->tgl_rev_dalnis)) ." | ".
							 date('H:i:s', strtotime($data_agr->tgl_rev_dalnis));

		$tgl_rev_dt  = date('d', strtotime($data_agr->tgl_rev_daltu)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_rev_daltu))) ." ".
							 date('Y', strtotime($data_agr->tgl_rev_daltu)) ." | ".
							 date('H:i:s', strtotime($data_agr->tgl_rev_daltu));

		//--> tgl persiapan, pelaksanaan, dan penyelesaian
		$tgl1_persiapan = date('d', strtotime($data_agr->rev_tgl1_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl1_persiapan))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl1_persiapan));
		$tgl2_persiapan = date('d', strtotime($data_agr->rev_tgl2_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl2_persiapan))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl2_persiapan));

		$tgl1_pelaksanaan = date('d', strtotime($data_agr->rev_tgl1_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl1_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl1_pelaksanaan));
		$tgl2_pelaksanaan = date('d', strtotime($data_agr->rev_tgl2_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl2_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl2_pelaksanaan));

		$tgl1_penyelesaian = date('d', strtotime($data_agr->rev_tgl1_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl1_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl1_penyelesaian));
		$tgl2_penyelesaian = date('d', strtotime($data_agr->rev_tgl2_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->rev_tgl2_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->rev_tgl2_penyelesaian));

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'data'         => $data_agr,
				'anggaran'     => $this->anggaran_waktu_m->get_rev_anggaran_waktu2($key, $key2),
				'tgl_rev'      => $tgl_rev,
				'tgl_rev_dn'   => $tgl_rev_dn,
				'tgl_rev_dt'   => $tgl_rev_dt,
				'tgl1_1'       => $tgl1_persiapan,
				'tgl2_1'       => $tgl2_persiapan,
				'tgl1_2'       => $tgl1_pelaksanaan,
				'tgl2_2'       => $tgl2_pelaksanaan,
				'tgl1_3'       => $tgl1_penyelesaian,
				'tgl2_3'       => $tgl2_penyelesaian
			);

		$this->load->view('ketua_tim/anggaran_waktu/detail_rev_anggaran_waktu', $data);
	}

	//--> temporary anggaran waktu
	public function tambah_anggaran_waktu($id_tugas, $id_tim)
	{
		$get_akun  = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$key  = base64_decode($id_tugas);
		$key2 = base64_decode($id_tim);

		$tanggal = date('d') ." ". get_nama_bulan(date('m')) ." ". date('Y');

		$penugasan = $this->penugasan_m->get_row_penugasan($key);

		$daltu 	   = $this->db->get_where('tb_pegawai', array('id_pegawai' => $penugasan->daltu))->row();
		$dalnis 	 = $this->db->get_where('tb_pegawai', array('id_pegawai' => $penugasan->dalnis))->row();

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'tanggal'      => $tanggal,
				'id_agr'       => $this->anggaran_waktu_m->get_id_max_agr(),
				'jp'           => $this->anggaran_waktu_m->get_set_anggaran(),
				'total'        => $this->anggaran_waktu_m->count_set_anggaran(),
				'data'         => $penugasan,
				'daltu'        => $daltu,
				'dalnis'       => $dalnis,
				'pegawai'      => $this->login_model->get_pegawai($this->session->userdata('username')),
				'anggota'      => $this->tim_m->get_sub_tim($key2)
			);

		$this->load->view('ketua_tim/anggaran_waktu/form_tambah_anggaran_waktu', $data);

		//--> jika form submit
		if($this->input->post('submit'))
		{
			//echo "SIMPAN FIXED";
			$id  = base64_encode($this->input->post('id_agr'));
			$id2 = $this->input->post('id_agr');
			$this->anggaran_waktu_m->insert_anggaran_waktu(); //insert anggaran waktu

			$cek = $this->db->query("SELECT * FROM temp_aw1 WHERE id_anggaran_wkt = '$id2'")->num_rows();
			if($cek > 0)
			{ 
				$this->db->delete('temp_aw1', array('id_anggaran_wkt' => $id2));
				$this->db->delete('temp_aw2', array('sub_anggaran_wkt' => $id2));
			}

			//--> Tampilkan notifikasi berhasil ubah
			echo $this->session->set_flashdata('sukses',
					 "<div class='alert alert-block alert-success'>
							<button type='button' class='close' data-dismiss='alert'>
								<i class='ace-icon fa fa-times'></i>
							</button>

							<p>
								<strong>
									<i class='ace-icon fa fa-check'></i>
									Berhasil Membuat Anggaran Waktu!
								</strong>
								Data alokasi anggaran waktu telah ditambahkan, cek data tersebut di bawah ini.
							</p>
						</div>"
				);

			redirect('ketua_tim/anggaran_waktu/detail_anggaran_waktu/'.$id);
		}
		elseif($this->input->post('temp'))
		{
			//echo "SIMPAN TEMPORARY";
			$id  = $this->input->post('id_agr');
			$id1 = base64_encode($this->input->post('id_tgs'));
			$id2 = base64_encode($this->input->post('id_tim'));
			$cek = $this->db->query("SELECT * FROM temp_aw1 WHERE id_anggaran_wkt = '$id'")->num_rows();

			if($cek > 0) { $this->anggaran_waktu_m->update_temp_aw(); }
			else { $this->anggaran_waktu_m->insert_temp_aw(); }

			//$this->anggaran_waktu_m->insert_temp_aw();

			//--> Tampilkan notifikasi berhasil ubah
			echo $this->session->set_flashdata('sukses',
					 "<div class='alert alert-block alert-success'>
							<button type='button' class='close' data-dismiss='alert'>
								<i class='ace-icon fa fa-times'></i>
							</button>

							<p>
								<strong>
									<i class='ace-icon fa fa-check'></i>
									Berhasil Simpan Temp Anggaran Waktu!
								</strong>
								Data anggaran waktu berhasil di simpan secara temporary, cek data dengan klik <i><strong>Buat Alokasi Anggaran Waktu</strong></i>.
							</p>
						</div>"
				);

			redirect('ketua_tim/penugasan/detail_penugasan/'.$id1.'/'.$id2);

		/*	$id_agr = $this->input->post('id_agr');
			$id_tim = $this->input->post('id_tim');
			$kod = $this->input->post('kode_pekerjaan');
			$jen = $this->input->post('jenis_pekerjaan');

			$hri1 = $this->input->post('hari_daltu');
			$hri2 = $this->input->post('hari_dalnis');
			$hri3 = $this->input->post('hari_ketua');
			$hri4 = $this->input->post('hari_anggota');

			$jam1 = $this->input->post('jam_daltu');
			$jam2 = $this->input->post('jam_dalnis');
			$jam3 = $this->input->post('jam_ketua');
			$jam4 = $this->input->post('jam_anggota');

			$kta = $this->input->post('kategori');
			$tot = $this->input->post('total');

			echo "
			<table border='1'>
				<tr>
					<td> JENIS PEKERJAAN </td>
					<td> DALTU </td>
					<td> DALNIS </td>
					<td> KETUA </td>
					<td> ANGGOTA </td>
					<td> JUMLAH </td>
				</tr>

				<tr><td colspan='6'>&nbsp;</td></tr>
			";

			$i = 0;
			while($i < $tot)
			{
				$no = $i+1;

				if($this->input->post('daltu_'.$no) == 'aktif')
				{
					$daltu 		 = $this->input->post('daltu_'.$no);
					$hri_daltu = $hri1[$i];
					$jam_daltu = number_format($jam1[$i],2);
				}
				else
				{
					$daltu 		 = $this->input->post('daltu_'.$no);
					$hri_daltu = "-";
					$jam_daltu = "-";
				}

				if($this->input->post('dalnis_'.$no) == 'aktif')
				{
					$dalnis 		  = $this->input->post('dalnis_'.$no);
					$hri_dalnis = $hri2[$i];
					$jam_dalnis = number_format($jam2[$i],2);
				}
				else
				{
					$dalnis 		  = $this->input->post('dalnis_'.$no);
					$hri_dalnis = "-";
					$jam_dalnis = "-";
				}

				if($this->input->post('ketua_'.$no) == 'aktif')
				{
					$ketua 		 = $this->input->post('ketua_'.$no);
					$hri_ketua = $hri3[$i];
					$jam_ketua = number_format($jam3[$i],2);
				}
				else
				{
					$ketua 		 = $this->input->post('ketua_'.$no);
					$hri_ketua = "-";
					$jam_ketua = "-";
				}

				if($this->input->post('anggota_'.$no) == 'aktif')
				{
					$anggota 		 = $this->input->post('anggota_'.$no);
					$hri_anggota = $hri4[$i];
					$jam_anggota = number_format($jam4[$i],2);
				}
				else
				{
					$anggota 		 = $this->input->post('anggota_'.$no);
					$hri_anggota = "-";
					$jam_anggota = "-";
				}

				$jml_hri = $hri_daltu + $hri_dalnis + $hri_ketua + $hri_anggota;
				$jml_2 = $jam_daltu + $jam_dalnis + $jam_ketua + $jam_anggota;

				$jml_jam = number_format($jml_2,2);

				echo "
					<tr>
						<td> $jen[$i] $kod[$i] </td>
						<td> $daltu | hari : $hri_daltu | jam : $jam_daltu </td>
						<td> $dalnis | hari : $hri_dalnis | jam : $jam_dalnis </td>
						<td> $ketua | hari : $hri_ketua | jam : $jam_ketua </td>
						<td> $anggota | hari : $hri_anggota | jam : $jam_anggota </td>
						<td> hari : $jml_hri | jam : $jml_jam </td>
					</tr>
				";

				$i++;
			}
			echo "</table> <br/><br/>";*/
		}
	}

	//--> hasil temporary anggaran waktu
	public function temp_anggaran_waktu($id_tugas, $id_tim, $id_agr)
	{
		$get_akun  = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$key  = base64_decode($id_tugas);
		$key2 = base64_decode($id_tim);
		$key3 = base64_decode($id_agr);

		$tanggal = date('d') ." ". get_nama_bulan(date('m')) ." ". date('Y');

		$penugasan = $this->penugasan_m->get_row_penugasan($key);
		$data_agr  = $this->anggaran_waktu_m->get_row_aw_temp($key3);
		$sub_agr 	 = $this->anggaran_waktu_m->get_sub_aw_temp($key3);

		$daltu 	   = $this->db->get_where('tb_pegawai', array('id_pegawai' => $penugasan->daltu))->row();
		$dalnis 	 = $this->db->get_where('tb_pegawai', array('id_pegawai' => $penugasan->dalnis))->row();

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'tanggal'      => $tanggal,
				'id_agr'       => $this->anggaran_waktu_m->get_id_max_agr(),
				//'jp'           => $this->anggaran_waktu_m->get_set_anggaran(),
				'total'        => $this->anggaran_waktu_m->count_agr_temp($key3),
				'data'         => $penugasan,
				'data_agr'		 => $data_agr,
				'sub_agr'      => $sub_agr,
 				'daltu'        => $daltu,
				'dalnis'       => $dalnis,
				'pegawai'      => $this->login_model->get_pegawai($this->session->userdata('username')),
				'anggota'      => $this->tim_m->get_sub_tim($key2)
			);

		$this->load->view('ketua_tim/anggaran_waktu/form_temp_anggaran_waktu', $data);

		//--> jika form submit
		if($this->input->post('submit'))
		{
			//$id  = base64_encode($this->input->post('id_agr'));
			//$this->anggaran_waktu_m->insert_anggaran_waktu();

			//--> Tampilkan notifikasi berhasil ubah
			/*echo $this->session->set_flashdata('sukses',
					 "<div class='alert alert-block alert-success'>
							<button type='button' class='close' data-dismiss='alert'>
								<i class='ace-icon fa fa-times'></i>
							</button>

							<p>
								<strong>
									<i class='ace-icon fa fa-check'></i>
									Berhasil Membuat Anggaran Waktu!
								</strong>
								Data alokasi anggaran waktu telah ditambahkan, cek data tersebut di bawah ini.
							</p>
						</div>"
				);

			redirect('ketua_tim/anggaran_waktu/detail_anggaran_waktu/'.$id);*/

			/*$id_agr = $this->input->post('id_agr');
			$id_tim = $this->input->post('id_tim');
			$kod = $this->input->post('kode_pekerjaan');
			$jen = $this->input->post('jenis_pekerjaan');

			$hri1 = $this->input->post('hari_daltu');
			$hri2 = $this->input->post('hari_dalnis');
			$hri3 = $this->input->post('hari_ketua');
			$hri4 = $this->input->post('hari_anggota');

			$jam1 = $this->input->post('jam_daltu');
			$jam2 = $this->input->post('jam_dalnis');
			$jam3 = $this->input->post('jam_ketua');
			$jam4 = $this->input->post('jam_anggota');

			$kta = $this->input->post('kategori');
			$tot = $this->input->post('total');

			echo "
			<table border='1'>
				<tr>
					<td> JENIS PEKERJAAN </td>
					<td> DALTU </td>
					<td> DALNIS </td>
					<td> KETUA </td>
					<td> ANGGOTA </td>
					<td> JUMLAH </td>
				</tr>

				<tr><td colspan='6'>&nbsp;</td></tr>
			";

			$i = 0;
			while($i < $tot)
			{
				$no = $i+1;

				if($this->input->post('daltu_'.$no) == 'aktif')
				{
					$daltu 		 = $this->input->post('daltu_'.$no);
					$hri_daltu = $hri1[$i];
					$jam_daltu = number_format($jam1[$i],2);
				}
				else
				{
					$daltu 		 = $this->input->post('daltu_'.$no);
					$hri_daltu = "-";
					$jam_daltu = "-";
				}

				if($this->input->post('dalnis_'.$no) == 'aktif')
				{
					$dalnis 		  = $this->input->post('dalnis_'.$no);
					$hri_dalnis = $hri2[$i];
					$jam_dalnis = number_format($jam2[$i],2);
				}
				else
				{
					$dalnis 		  = $this->input->post('dalnis_'.$no);
					$hri_dalnis = "-";
					$jam_dalnis = "-";
				}

				if($this->input->post('ketua_'.$no) == 'aktif')
				{
					$ketua 		 = $this->input->post('ketua_'.$no);
					$hri_ketua = $hri3[$i];
					$jam_ketua = number_format($jam3[$i],2);
				}
				else
				{
					$ketua 		 = $this->input->post('ketua_'.$no);
					$hri_ketua = "-";
					$jam_ketua = "-";
				}

				if($this->input->post('anggota_'.$no) == 'aktif')
				{
					$anggota 		 = $this->input->post('anggota_'.$no);
					$hri_anggota = $hri4[$i];
					$jam_anggota = number_format($jam4[$i],2);
				}
				else
				{
					$anggota 		 = $this->input->post('anggota_'.$no);
					$hri_anggota = "-";
					$jam_anggota = "-";
				}

				$jml_hri = $hri_daltu + $hri_dalnis + $hri_ketua + $hri_anggota;
				$jml_2 = $jam_daltu + $jam_dalnis + $jam_ketua + $jam_anggota;

				$jml_jam = number_format($jml_2,2);

				echo "
					<tr>
						<td> $jen[$i] $kod[$i] </td>
						<td> $daltu | hari : $hri_daltu | jam : $jam_daltu </td>
						<td> $dalnis | hari : $hri_dalnis | jam : $jam_dalnis </td>
						<td> $ketua | hari : $hri_ketua | jam : $jam_ketua </td>
						<td> $anggota | hari : $hri_anggota | jam : $jam_anggota </td>
						<td> hari : $jml_hri | jam : $jml_jam </td>
					</tr>
				";

				$i++;
			}
			echo "</table> <br/><br/>";*/
		}
	}

	//--> reviu anggaran waktu
	public function reviu_anggaran_waktu($id_agr, $id_tugas, $id_tim)
	{
		$get_akun  = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));
		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$key  = base64_decode($id_tugas);
		$key2 = base64_decode($id_tim);
		$key3 = base64_decode($id_agr);

		$penugasan = $this->penugasan_m->get_row_penugasan($key);
		$data_agr  = $this->anggaran_waktu_m->get_row_anggaran_waktu($key3);
		$tanggal   = date('d') ." ". get_nama_bulan(date('m')) ." ". date('Y');
		$sub_agr 	 = $this->anggaran_waktu_m->get_sub_anggaran_waktu($key3);

		$tgl_rev_dn  = date('d', strtotime($data_agr->tgl_dalnis)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_dalnis))) ." ".
							 date('Y', strtotime($data_agr->tgl_dalnis)) ." | ".
							 date('H:i:s', strtotime($data_agr->tgl_dalnis));

		$tgl_rev_dt  = date('d', strtotime($data_agr->tgl_daltu)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_daltu))) ." ".
							 date('Y', strtotime($data_agr->tgl_daltu)) ." | ".
							 date('H:i:s', strtotime($data_agr->tgl_daltu));

		$data = array(
				'user'         => $get_akun,
				'level'        => $get_akun,
				'jml_notif'    => $this->notifikasi_m->jml_notif_ketua($kt->id_pegawai),
				'notif'        => $this->notifikasi_m->notif_ketua($kt->id_pegawai),
				'jml_notifAgr' => $this->notifikasi_m->jml_notif_ketuaAgr($kt->id_pegawai),
				'notifAgr'     => $this->notifikasi_m->notif_ketuaAgr($kt->id_pegawai),
				'jml_notifPka' => $this->notifikasi_m->jml_notif_ketuaPka($kt->id_pegawai),
				'notifPka'     => $this->notifikasi_m->notif_ketuaPka($kt->id_pegawai),
				'title'        => 'Anggaran Waktu [KETUA TIM] | Inspektorat Cianjur',
				'tanggal'      => $tanggal,
				'rev_ke'       => $this->anggaran_waktu_m->cek_rev_agr($key3),
				'total'        => $this->anggaran_waktu_m->count_agr($key3),
				'data'         => $penugasan,
				'data_agr'     => $data_agr,
				'sub_agr'      => $sub_agr,
				'tgl_rev_dn'   => $tgl_rev_dn,
				'tgl_rev_dt'   => $tgl_rev_dt
			);

		$this->load->view('ketua_tim/anggaran_waktu/form_rev_anggaran_waktu', $data);

		//--> jika form submit
		if($this->input->post('submit'))
		{
			$id  = base64_encode($this->input->post('id_agr'));
			$this->anggaran_waktu_m->reviu_anggaran_waktu();

			//--> Tampilkan notifikasi berhasil ubah
			echo $this->session->set_flashdata('sukses',
					 "<div class='alert alert-block alert-success'>
							<button type='button' class='close' data-dismiss='alert'>
								<i class='ace-icon fa fa-times'></i>
							</button>

							<p>
								<strong>
									<i class='ace-icon fa fa-check'></i>
									Anggaran Waktu Berhasil Diubah!
								</strong>
								Data alokasi anggaran waktu telah diubah, cek data tersebut di bawah ini.
							</p>
						</div>"
				);

			redirect('ketua_tim/anggaran_waktu/detail_anggaran_waktu/'.$id);
		}
	}

	//--> cetak anggaran waktu
	public function cetak_anggaran_waktu($id_agr)
	{
		$pdf = $this->pdf->load_surat();

   		$key  = base64_decode($id_agr);

		$data_agr = $this->anggaran_waktu_m->get_row_anggaran_waktu($key);

		//--> tgl pembuatan anggaran waktu
		$tgl_agr = date('d', strtotime($data_agr->tgl_agr)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_agr))) ." ".
							 date('Y', strtotime($data_agr->tgl_agr));

		$tgl_dn = date('d', strtotime($data_agr->tgl_dalnis)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_dalnis))) ." ".
							 date('Y', strtotime($data_agr->tgl_dalnis));

		$tgl_dt = date('d', strtotime($data_agr->tgl_daltu)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_daltu))) ." ".
							 date('Y', strtotime($data_agr->tgl_daltu));

		//--> tgl persiapan, pelaksanaan, dan penyelesaian
		$tgl1_persiapan = date('d', strtotime($data_agr->tgl1_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_persiapan))) ." ".
							 date('Y', strtotime($data_agr->tgl1_persiapan));
		$tgl2_persiapan = date('d', strtotime($data_agr->tgl2_persiapan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_persiapan))) ." ".
							 date('Y', strtotime($data_agr->tgl2_persiapan));

		$tgl1_pelaksanaan = date('d', strtotime($data_agr->tgl1_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->tgl1_pelaksanaan));
		$tgl2_pelaksanaan = date('d', strtotime($data_agr->tgl2_pelaksanaan)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_pelaksanaan))) ." ".
							 date('Y', strtotime($data_agr->tgl2_pelaksanaan));

		$tgl1_penyelesaian = date('d', strtotime($data_agr->tgl1_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl1_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->tgl1_penyelesaian));
		$tgl2_penyelesaian = date('d', strtotime($data_agr->tgl2_penyelesaian)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl2_penyelesaian))) ." ".
							 date('Y', strtotime($data_agr->tgl2_penyelesaian));

		$daltu 	   = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->daltu))->row();
		$dalnis 	 = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->dalnis))->row();
		$ketua_tim = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->ketua_tim))->row();

		$data = array(
				'data'      => $data_agr,
				'anggaran' 	=> $this->anggaran_waktu_m->get_sub_anggaran_waktu($key),
				'tgl_agr'		=> $tgl_agr,
				'tgl_dn'		=> $tgl_dn,
				'tgl_dt'		=> $tgl_dt,
				'tgl1_1'		=> $tgl1_persiapan,
				'tgl2_1'		=> $tgl2_persiapan,
				'tgl1_2'		=> $tgl1_pelaksanaan,
				'tgl2_2'		=> $tgl2_pelaksanaan,
				'tgl1_3'		=> $tgl1_penyelesaian,
				'tgl2_3'		=> $tgl2_penyelesaian,
				'daltu_tim'	=> $daltu,
				'dalnis_tim'=> $dalnis,
				'ketua_tim'	=> $ketua_tim,
				'addPage'		=> $pdf->AddPage()
			);
	//$this->load->view('ketua_tim/anggaran_waktu/cetak_anggaran_waktu', $data);
		
    $html = $this->load->view('ketua_tim/anggaran_waktu/cetak_anggaran_waktu', $data, TRUE);
    //--> render the view into HTML
    $pdf->WriteHTML($html);
    //--> write the HTML into the PDF
    $output = 'Anggaran_Waktu_'. $key .'_.pdf';
    $pdf->Output($output, 'I');
	}

	//--> cetak kartu penugasan
	public function cetak_kartu_penugasan($id_agr)
	{
		$pdf = $this->pdf->load_surat();

   	$key = base64_decode($id_agr);

		$data_agr = $this->anggaran_waktu_m->get_row_anggaran_waktu($key);

		//--> tgl pembuatan anggaran waktu
		$tgl_agr = date('d', strtotime($data_agr->tgl_agr)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_agr))) ." ".
							 date('Y', strtotime($data_agr->tgl_agr));

		$tgl_dn = date('d', strtotime($data_agr->tgl_dalnis)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_dalnis))) ." ".
							 date('Y', strtotime($data_agr->tgl_dalnis));

		$tgl_dt = date('d', strtotime($data_agr->tgl_daltu)) ." ".
							 get_nama_bulan(date('m', strtotime($data_agr->tgl_daltu))) ." ".
							 date('Y', strtotime($data_agr->tgl_daltu));

		$cek = $this->db->get_where('tb_surat', array('fk_tim' => $data_agr->id_tim))->row();
		$tgl_surat = date('d', strtotime($cek->tgl_surat)) ." ".
							 get_nama_bulan(date('m', strtotime($cek->tgl_surat))) ." ".
							 date('Y', strtotime($cek->tgl_surat));

		$tgl_awal	 = date('d', strtotime($cek->tgl_awal)) ." ".
							 get_nama_bulan(date('m', strtotime($cek->tgl_awal))) ." ".
							 date('Y', strtotime($cek->tgl_awal));

		$tgl_akhir = date('d', strtotime($cek->tgl_akhir)) ." ".
							 get_nama_bulan(date('m', strtotime($cek->tgl_akhir))) ." ".
							 date('Y', strtotime($cek->tgl_akhir));

		$daltu 	   = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->daltu))->row();
		$dalnis 	 = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->dalnis))->row();
		$ketua_tim = $this->db->get_where('tb_pegawai', array('id_pegawai' => $data_agr->ketua_tim))->row();

		$data = array(
				'data'      	=> $data_agr,
				'anggaran' 		=> $this->anggaran_waktu_m->get_sub_anggaran_waktu($key),
				'tgl_agr'			=> $tgl_agr,
				'tgl_dn'			=> $tgl_dn,
				'tgl_dt'			=> $tgl_dt,
				'daltu_tim'		=> $daltu,
				'dalnis_tim'	=> $dalnis,
				'ketua_tim'		=> $ketua_tim,
				'anggota_tim'	=> $this->tim_m->get_sub_tim($data_agr->id_tim),
				'tgl_surat' 	=> $tgl_surat,
				'tgl_awal'		=> $tgl_awal,
				'tgl_akhir'		=> $tgl_akhir,
				'addPage'			=> $pdf->AddPage()
			);
	//$this->load->view('ketua_tim/anggaran_waktu/cetak_kartu_penugasan', $data);
		
    $html = $this->load->view('ketua_tim/anggaran_waktu/cetak_kartu_penugasan', $data, TRUE);
    //--> render the view into HTML
    $pdf->WriteHTML($html);
    //--> write the HTML into the PDF
    $output = 'Kartu_Penugasan_'. $key .'_.pdf';
    $pdf->Output($output, 'I');
	}

}