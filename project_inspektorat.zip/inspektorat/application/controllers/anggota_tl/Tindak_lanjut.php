<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tindak_lanjut extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('login_model');
		$this->auth->cek_auth(); //--> ambil auth dari library

		//--> load model
		$this->load->model('notifikasi_m');
		$this->load->model('staff/tindak_lanjut_m');
		$this->load->model('staff/penugasan_m');
		$this->load->model('staff/tim_m');
		$this->load->model('staff/surat_m');
		$this->load->model('staff/instansi_m');

		//--> hak akses
		$hak_akses = $this->session->userdata('lvl');
		if($hak_akses!='anggota_tl')
		{
			echo "<script>alert('Anda tidak berhak mengakses halaman ini!!');</script>";
			redirect('log_in','refresh');
			exit();
		}
		// ./hak akses
	}

	//--> list penugasan
	public function index()
	{
		$get_akun = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));

		$kt = $this->login_model->get_pegawai($this->session->userdata('username'));

		$data = array(
				'user'     	=> $get_akun,
        'level'	   	=> $get_akun,
        'jml_notif' => $this->notifikasi_m->jml_notif_staff(),
        'notif'		 	=> $this->notifikasi_m->notif_staff(),
        'title'		 	=> 'Tindak Lanjut [KETUA TIM TL] | Inspektorat Cianjur',
				'tl' 	 			=> $this->tindak_lanjut_m->get_tugas_ag($kt->id_pegawai)
			);

		$this->load->view('anggota_tl/tindak_lanjut/list_tl', $data);
	}

	//--> detail penugasan
	public function detail_tl($id_tl, $id_tim, $no_lhp)
	{
		$get_akun = $this->login_model->get_user($this->session->userdata('username'), $this->session->userdata('lvl'));

		$key  = base64_decode($id_tl);
		$key2 = base64_decode($id_tim);
		$key3 = base64_decode($no_lhp);

		//-> update notif penugasan
		//$this->notifikasi_m->update_notif_staff($key);

		$cek = $this->db->get_where('tb_tindak_lanjut', array('id_tl' => $key))->row();

		$tgl_tl    = date('d', strtotime($cek->tgl_tl)) ." ".
							 get_nama_bulan(date('m', strtotime($cek->tgl_tl))) ." ".
							 date('Y', strtotime($cek->tgl_tl));

		$data_tl = $this->tindak_lanjut_m->get_sub_row_tl1($key, $key3);

		$tgl_lhp = date('d', strtotime($data_tl->tgl_lhp)) ." ".
							 get_nama_bulan(date('m', strtotime($data_tl->tgl_lhp))) ." ".
							 date('Y', strtotime($data_tl->tgl_lhp));
		

		$cek2 = $this->db->get_where('tb_surat', array('fk_tim' => $key2))->row();
		$tgl_surat = date('d', strtotime($cek2->tgl_surat)) ." ".
							 get_nama_bulan(date('m', strtotime($cek2->tgl_surat))) ." ".
							 date('Y', strtotime($cek2->tgl_surat));

		$tgl_awal	 = date('d', strtotime($cek2->tgl_awal)) ." ".
							 get_nama_bulan(date('m', strtotime($cek2->tgl_awal))) ." ".
							 date('Y', strtotime($cek2->tgl_awal));

		$tgl_akhir = date('d', strtotime($cek2->tgl_akhir)) ." ".
							 get_nama_bulan(date('m', strtotime($cek2->tgl_akhir))) ." ".
							 date('Y', strtotime($cek2->tgl_akhir));

		$penugasan = $this->tindak_lanjut_m->get_row_tl($key);
		$ketua_tim = $this->db->get_where('tb_pegawai', array('id_pegawai' => $penugasan->ketua_tim))->row();
		$jml_sas   = $this->tim_m->get_jum_sasaran($key2);

		if($jml_sas->jml != 0)
			{ $get_lhp = $this->tindak_lanjut_m->get_lhp($cek->fk_tgs); }
		else
			{ $get_lhp = $this->tindak_lanjut_m->get_row_lhp($cek->fk_tgs); }

		$data = array(
				'user'      => $get_akun,
				'level'     => $get_akun,
				'jml_notif' => $this->notifikasi_m->jml_notif_staff(),
        'notif'		 	=> $this->notifikasi_m->notif_staff(),
				'title'     => 'Tindak Lanjut [ANGGOTA TIM TL] | Inspektorat Cianjur',
				'data'      => $penugasan,
				'data2'     => $data_tl,
				'ketua_tim'	=> $ketua_tim,
				'tgl_tl'    => $tgl_tl,
				'tgl_surat' => $tgl_surat,
				'tgl_awal'	=> $tgl_awal,
				'tgl_akhir'	=> $tgl_akhir,
				'tim'      	=> $this->tim_m->get_sub_tim($key2),
				'jml_sas' 	=> $jml_sas,
				'lhp'				=> $get_lhp,
				'tgl_lhp'   => $tgl_lhp,
				'sub_tl2'   => $this->tindak_lanjut_m->get_sub_tl2($key, $key3)
			);

		$this->load->view('anggota_tl/tindak_lanjut/detail_tl', $data);
	}

	public function penentuan_kat()
	{
		$id_tl  = $this->input->post('id1');
		$no_lhp = $this->input->post('id2');
		$nomor  = $this->input->post('id3');

		$data['data'] = $this->tindak_lanjut_m->get_row_sub_tl2($id_tl, $no_lhp, $nomor);
		$this->load->view('anggota_tl/tindak_lanjut/penentuan_kat', $data);

		//--> jika form submit
		if($this->input->post('submit'))
		{
			$key  = base64_encode($this->input->post('id_tl'));
			$key2 = base64_encode($this->input->post('id_tim'));
			$key3 = base64_encode($this->input->post('no_lhp'));

			$this->tindak_lanjut_m->penentuan_kategori();

			//--> Tampilkan notifikasi berhasil ubah
			echo $this->session->set_flashdata('sukses',
					 "<div class='alert alert-block alert-success'>
							<button type='button' class='close' data-dismiss='alert'>
								<i class='ace-icon fa fa-times'></i>
							</button>

							<p>
								<strong>
									<i class='ace-icon fa fa-check'></i>
									Berhasil Memberikan Keputusan!
								</strong>
								Kategori tindak lanjut telah ditentukan, cek data tersebut di bawah ini.
							</p>
						</div>"
				);

			redirect('anggota_tl/tindak_lanjut/detail_tl/'.$key.'/'.$key2.'/'.$key3);
		}
	}

}